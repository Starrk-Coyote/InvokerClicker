using UnityEngine;
using TMPro;

public class InvokerClicker : MonoBehaviour
{
    [Header("UI Элементы")]
    public TextMeshProUGUI goldText;
    public TextMeshProUGUI exortText;
    public TextMeshProUGUI wexText;
    public TextMeshProUGUI quasText;

    [Header("Звуки")]
    public AudioSource audioSource; // Компонент для воспроизведения
    public AudioClip clickSound;    // Звук клика по Инвокеру
    public AudioClip buySound;     // Звук покупки сферы

    [Header("Ресурсы")]
    public float gold = 0;

    [Header("Сферы и цены")]
    public int exortLevel = 0;
    public int wexLevel = 0;
    public int quasLevel = 0;

    private int exortCost = 15;
    private int wexCost = 25;
    private int quasCost = 50;

    private float quasTimer = 0f;
    private float lastClickTime = 0f;

    void Start()
    {
        UpdateUI();
    }

    void Update()
    {
        if (quasLevel > 0)
        {
            quasTimer += Time.deltaTime;
            float quasCooldown = Mathf.Max(0.5f, 4f - (quasLevel * 0.3f));

            if (quasTimer >= quasCooldown)
            {
                AutoClick();
                quasTimer = 0f;
            }
        }
    }

    public void OnInvokerClick()
    {
        float clickCooldown = Mathf.Max(0.02f, 0.2f - (wexLevel * 0.02f));

        if (Time.time - lastClickTime >= clickCooldown)
        {
            AddMoney();
            // 🔊 ЗВУК: Воспроизводим звук клика
            if (audioSource != null && clickSound != null)
                audioSource.PlayOneShot(clickSound);

            lastClickTime = Time.time;
        }
    }

    void AutoClick()
    {
        AddMoney();
    }

    void AddMoney()
    {
        gold += 1 + (exortLevel * 2);
        UpdateUI();
    }

    public void BuyExort()
    {
        if (gold >= exortCost)
        {
            gold -= exortCost;
            exortLevel++;
            exortCost = Mathf.RoundToInt(exortCost * 1.5f);
            PlayBuySound(); // 🔊 ЗВУК
            UpdateUI();
        }
    }

    public void BuyWex()
    {
        if (gold >= wexCost && wexLevel < 9)
        {
            gold -= wexCost;
            wexLevel++;
            wexCost = Mathf.RoundToInt(wexCost * 1.6f);
            PlayBuySound(); // 🔊 ЗВУК
            UpdateUI();
        }
    }

    public void BuyQuas()
    {
        if (gold >= quasCost)
        {
            gold -= quasCost;
            quasLevel++;
            quasCost = Mathf.RoundToInt(quasCost * 1.7f);
            PlayBuySound(); // 🔊 ЗВУК
            UpdateUI();
        }
    }

    // 🔊 ЗВУК: Метод для проигрывания звука покупки
    void PlayBuySound()
    {
        if (audioSource != null && buySound != null)
            audioSource.PlayOneShot(buySound);
    }

    void UpdateUI()
    {
        goldText.text = $"Золото: {Mathf.FloorToInt(gold)} 💰";
        exortText.text = $"Exort (Lvl {exortLevel})\nЦена: {exortCost}";
        wexText.text = $"Wex (Lvl {wexLevel}/9)\nЦена: {wexCost}";
        quasText.text = $"Quas (Lvl {quasLevel})\nЦена: {quasCost}";
    }
}
